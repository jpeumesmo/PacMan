import java.util.Scanner;

public class ServidorPacMan {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int porta;
		
		System.out.println("Digite o numero da porta\n");
		porta = in.nextInt();
		in.nextLine();
		
		Server servidor = new Server();
		servidor.setPorta(porta);
		
		servidor.start();
		
		in.close();
	}
}
