import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread{
	//ATRIBUTOS
	private static ServerSocket server;
	private int porta;
	
	//METODOS
	public void run(){
		Server.servidor(porta);
	}
	
	public int getPorta() {
		return porta;
	}

	public void setPorta(int porta) {
		this.porta = porta;
	}

	public static void servidor(int porta){

		try {

			setServer(new ServerSocket(porta));;


			//////////////////////////////////
			while(true){
				System.out.println("Servidor ouvindo a porta "+ porta);
				// o metodo accept() bloqueia a execucao ate que
				// o servidor receba um pedido de conexao
				Socket cliente = server.accept();

				//VARIAVEIS DE COMUNICACAO
				DataInputStream tipoOperacao = new DataInputStream(cliente.getInputStream());
			//	ObjectInputStream objetoRecebido = new ObjectInputStream(cliente.getInputStream());
			//	ObjectOutputStream objetoEnviado = new ObjectOutputStream(cliente.getOutputStream());
			//	DataOutputStream resposta = new DataOutputStream(cliente.getOutputStream());

				//VARIAVEIS PARA RECEBER E ENVIAR ARQUIVOS
				switch (tipoOperacao.readInt()){
				//logar
				case 1:
					logar();
					break;
				//get	
				case 2:
					get();
					break;
				//put
				case 3:
					put();
					break;

				default:

					break;
				}
				
			}	
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		public static ServerSocket getServer() {
			return server;
		}

		public static void setServer(ServerSocket server) {
			Server.server = server;
		}
	
		public static void logar(){
			System.out.println("usuario logando");
		}
		
		public static void get(){
			
		}
		
		public static void put(){
			
		}
}
