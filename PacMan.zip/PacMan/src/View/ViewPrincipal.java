package View;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Control.TCPClient;

public class ViewPrincipal extends Thread{
	
	//ATRIBUTOS
	static int id;
	static JFrame janelaPrincipal;
	static JPanel painelPrincipal;
	
	//METODOS
	public void run(){
		janelaPrincipal();
		conectar();
		
		janelaPrincipal.setLocationRelativeTo(null);
		janelaPrincipal.setVisible(true);

	}
	
	public static void janelaPrincipal(){
		painelPrincipal = new JPanel();
		painelPrincipal.setLayout(new BorderLayout());

		janelaPrincipal = new JFrame("PACMAN Cliente ");
		janelaPrincipal.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		janelaPrincipal.add(painelPrincipal);
		janelaPrincipal.setSize(340,325);

	}
	
	
	public static void conectar(){
		JPanel painelFields = new JPanel(new GridLayout(1, 4));
		JPanel painelImagem = new JPanel(new GridLayout(1, 1));
		JPanel painelBotao = new JPanel(new GridLayout(1,1));
		
		JLabel labelIP = new JLabel("IP:");
		JTextField fieldIP = new JTextField();
		fieldIP.setText("localhost");
		fieldIP.select(0, fieldIP.getText().length());
		
		JLabel labelPorta = new JLabel("Porta: ");
		JTextField fieldPorta = new JTextField();
		
		fieldPorta.setText("2024");
		fieldPorta.select(0, fieldPorta.getText().length());
		
		JButton botaoConectar = new JButton("Conectar !");
		
		ImageIcon imagem = new ImageIcon("pacman.gif", "imagem pac-man");
		JLabel labelImagem = new JLabel(imagem);
		
		labelImagem.setBounds(0, 0, 340, 240);
		
		painelImagem.add(labelImagem);
		
		painelBotao.add(botaoConectar);
		
		painelFields.add(labelIP);
		painelFields.add(fieldIP);
		painelFields.add(labelPorta);
		painelFields.add(fieldPorta);
		
		painelPrincipal.add(painelFields, BorderLayout.NORTH);
		painelPrincipal.add(painelImagem,BorderLayout.CENTER);
		painelPrincipal.add(painelBotao,BorderLayout.SOUTH);
		
		
		botaoConectar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				TCPClient cliente = new TCPClient(fieldIP.getText(), Integer.parseInt(fieldPorta.getText()), null);
				cliente.setOp(3);
				cliente.start();
			}
		});
	}
	
	public static void jogo(){
		
	}
}

