package Control;

interface Cliente {

	abstract boolean put(String ip, int porta, Jogada jogada);
	abstract Jogada get(String ip, int porta);
	abstract boolean logar(String ip, int porta);
}
