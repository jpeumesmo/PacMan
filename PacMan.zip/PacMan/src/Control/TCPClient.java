package Control;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class TCPClient extends Thread implements Cliente{

	//ATRIBUTOS
	private static Socket cliente;
	private int op;
	private String ip;
	private int porta;
	private Jogada jogada;


	//METODOS	
	public void run(){
		switch(this.getOp()){

		case 1:
			this.put(ip, porta, jogada);
			break;

		case 2:
			this.get(ip, porta);
			break;

		case 3:
			this.logar(ip, porta);
			break;

		default:
			break;
		}
	}

	public TCPClient (String ip, int porta, Jogada jogada){
		this.ip = ip;
		this.porta = porta;
		this.jogada = jogada;
	}

	public boolean put(String ip, int porta, Jogada jogada) {
		// TODO Auto-generated method stub

		try {

			setCliente(new Socket(ip,porta));

			DataOutputStream tipoOperacao = new DataOutputStream(cliente.getOutputStream());
			ObjectOutputStream jogadaEnviada = new ObjectOutputStream(cliente.getOutputStream());

			DataInputStream resposta = new DataInputStream(cliente.getInputStream());

			tipoOperacao.writeInt(2);
			jogadaEnviada.writeObject(jogada);


			return resposta.readBoolean();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return false;
	}

	public Jogada get(String ip, int porta) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean logar(String ip, int porta) {
		// TODO Auto-generated method stub

		try {
			setCliente(new Socket(ip,porta));

			DataOutputStream tipoOperacao = new DataOutputStream(cliente.getOutputStream());
			
			tipoOperacao.writeInt(1);
			return true;
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public static Socket getCliente() {
		return cliente;
	}

	public static void setCliente(Socket cliente) {
		TCPClient.cliente = cliente;
	}

	public  int getOp() {
		return op;
	}

	public void setOp(int op) {
		this.op = op;
	}

}
