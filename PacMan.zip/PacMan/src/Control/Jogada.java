package Control;

import java.io.Serializable;

public class Jogada implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//ATRIBUTOS 
	int x;
	int y;
	
	//METODOS
	public boolean possibilidade(){
		
		if (true){//nao for parede
			return true;
		}else{
			return false;
		}
		
	}
}
