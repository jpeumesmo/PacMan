package Model;

import View.ViewPrincipal;

public class PacMan {
	public static void main(String[] args) {
		ViewPrincipal view = new ViewPrincipal();
		view.start();
	}
}
